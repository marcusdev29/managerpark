<?php
    include("conexao.php");
    $id = $_GET['id'];
?>
