<div id="contmenu">
<nav id="menu">
    <ul>
        <li><a href = "index.php"><button>Home</button></a></li>
        <li><a href = "estacionar-exibir.php"><button>Estacionar</button></a></li>
        <li><a href = "#"><button>Mensalistas</button></a></li>
        <li><a href = "#"><button>Mensalidades</button></a></li>
        <li><a href = "#"><button>Consultas</button></a></li>
        <li><a href = "#"><button>Usuários</button></a></li>
    </ul>
</nav>
</div>