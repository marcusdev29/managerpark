<?php
    $id = $_GET['id'];

   // echo "$id";

    include("conexao.php");
    $stmt = $pdo->prepare("delete from tbEstacionar where id='$id'");	
	$stmt ->execute();

    header("location:estacionar-exibir.php");
?>